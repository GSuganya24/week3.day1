package org.college;

public class College {
	 	public void collegeName() {
	 		System.out.println("College name is Anna University");
	 	}
	 	public void collegeCode() {
	 		System.out.println("College code is '073'");
	 	}
	 	public void collegeRank() { 
	 		System.out.println("College rank is five");
	 	}

}
