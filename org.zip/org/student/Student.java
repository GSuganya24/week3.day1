package org.student;

import org.department.Department;

public class Student extends Department{
	public void studentName() {
		System.out.println("Student name is Rishikesh");
	}
	public void studentDepartment() {
		System.out.println("Student department is Electronics");
	}
	public void studentId() {
		System.out.println("StudentId is '09D100'");
	}
	public static void main(String[] args) {
		Student details = new Student();
		details.collegeCode();
		details.collegeName();
		details.collegeRank();
		details.departmentName();
		details.studentName();
		details.studentDepartment();
		details.studentId();
	}

}
