package org.department;

import org.college.College;

public class Department extends College{
	public void departmentName() {
		System.out.println("Department name is Electronics");
	}

}
